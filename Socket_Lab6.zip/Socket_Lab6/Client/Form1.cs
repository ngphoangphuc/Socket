using System.Text;
using System.Net;
using System.Net.Sockets;   
namespace Client
{
    public partial class Form1 : Form
    {
        private Socket client;
        private IPEndPoint iep;
        private int port=1000;
        Thread t1;
        Thread t2;
        public Form1()
        {
            InitializeComponent();
        }

        private void startConnect()
        {
            iep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), port);
            client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            client.Connect(iep);
        }

        private void receiveMsg()
        {
            while (true)
            {
                if (client == null || client.Connected == false) continue;
                byte[] data = new byte[1024];
                int recv = client.Receive(data);
                String receiveMessage = decryption(data, recv);
                this.Invoke((MethodInvoker)delegate
                {
                    this.txt_group.Text += Environment.NewLine + "SERVER: " + receiveMessage;
                    if (txt_group.Visible)
                    {
                        txt_group.SelectionStart = txt_group.TextLength;
                        txt_group.ScrollToCaret();
                    }
                });
            }
        }

        private void sendMsg()
        {
            String message = txt_chat.Text;
            if (message == null) return;
            byte[] data = encryption(message);
            client.Send(data, data.Length, SocketFlags.None);
            this.Invoke((MethodInvoker)delegate
            {
                this.txt_group.Text += Environment.NewLine + "CLIENT: " + message;
                this.txt_chat.Text = "";
                if (txt_group.Visible)
                {
                    txt_group.SelectionStart = txt_group.TextLength;
                    txt_group.ScrollToCaret();
                }
            });

        }

        private byte[] encryption(String message)
        {
            byte[] data = new byte[1024];
            data = Encoding.ASCII.GetBytes(message);
            return data;
        }

        private String decryption(byte[] data, int recv)
        {
            return Encoding.ASCII.GetString(data, 0, recv);
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            t1 = new Thread(new ThreadStart(startConnect));
            t1.Start();
            t2 = new Thread(new ThreadStart(receiveMsg));
            t2.Start();
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            t1 = new Thread(new ThreadStart(sendMsg));
            t1.Start();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            t1.Interrupt();
            t2.Interrupt();
            client.Close();
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            t1 = new Thread(new ThreadStart(startConnect));
            t1.Start();
            t2 = new Thread(new ThreadStart(receiveMsg));
            t2.Start();
        }
    }
}