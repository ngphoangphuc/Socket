using System.Text;
using System.Net;
using System.Net.Sockets;

namespace Server
{
    public partial class Form1 : Form
    {
        private Socket server;
        private Socket client;
        private IPEndPoint iep;
        private int port=1000;
        Thread t1;
        Thread t2;
        Thread t3;
        public Form1()
        {
            InitializeComponent();
        }

        private void startConnect()
        {
            iep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), port);
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            server.Bind(iep);
            server.Listen(10);
            client = server.Accept();

            string infoMessage = "Accepted the connection!";

            byte[] data = encryption(infoMessage);
            client.Send(data, data.Length, SocketFlags.None);
            this.Invoke((MethodInvoker)delegate
            {
                this.txt_group.Text += Environment.NewLine + "SERVER: Received connection from Client!";
            });


        }

        private void receiveMsg()
        {
            while (true)
            {
                if (client == null) continue;
                byte[] data = new byte[1024];
                int recv = client.Receive(data);
                string receiveMessage = decryption(data, recv);
                this.Invoke((MethodInvoker)delegate
                {
                    this.txt_group.Text += Environment.NewLine + "CLIENT: " + receiveMessage;
                    if (txt_group.Visible)
                    {
                        txt_group.SelectionStart = txt_group.TextLength;
                        txt_group.ScrollToCaret();
                    }
                });
            }
        }

        private void sendMsg()
        {
            string message = txt_chat.Text;
            if (message == null) return;
            byte[] data = encryption(message);
            client.Send(data, data.Length, SocketFlags.None);
            this.Invoke((MethodInvoker)delegate
            {
                this.txt_group.Text += Environment.NewLine + "SERVER: " + message;
                this.txt_chat.Text = "";
                if (txt_group.Visible)
                {
                    txt_group.SelectionStart = txt_group.TextLength;
                    txt_group.ScrollToCaret();
                }
            });
        }

        private byte[] encryption(string message)
        {
            byte[] data = new byte[1024];
            data = Encoding.ASCII.GetBytes(message);
            return data;
        }

        private string decryption(byte[] data, int recv)
        {
            return Encoding.ASCII.GetString(data, 0, recv);
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            t1 = new Thread(new ThreadStart(startConnect));
            t1.Start();
            t2 = new Thread(new ThreadStart(receiveMsg));
            t2.Start();

        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            t3 = new Thread(new ThreadStart(sendMsg));
            t3.Start();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            t1.Interrupt();
            t2.Interrupt();
            server.Close();
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            t1 = new Thread(new ThreadStart(startConnect));
            t1.Start();
            t2 = new Thread(new ThreadStart(receiveMsg));
            t2.Start();

        }
    }
}